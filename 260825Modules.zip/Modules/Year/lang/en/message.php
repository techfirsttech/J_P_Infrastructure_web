<?php

return [
    'year' => 'Year',
    'list' => 'Year List',
    'add' => 'Add Year',
    'edit' => 'Edit Year',
    'name' => 'Year Name',
    'default' => 'Set Default',
    'enter_year' => 'Enter year name',
    'enter_unique_year' => 'Enter unique year name',
];
