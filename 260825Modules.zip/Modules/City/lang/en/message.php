<?php

return [
    'city' => 'City',
    'list' => 'City List',
    'add' => 'Add City',
    'edit' => 'Edit City',
    'state' => 'State',
    'country' => 'Country',
    'name' => 'City Name',
    'enter_name' => 'Enter city name',
    'enter_unique_name' => 'The city name has already been taken',
    'select_country' => 'Select country',
    'select_state' => 'Select state',
];
