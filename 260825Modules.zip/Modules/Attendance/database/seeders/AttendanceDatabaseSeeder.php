<?php

namespace Modules\Attendance\Database\Seeders;

use Illuminate\Database\Seeder;

class AttendanceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
