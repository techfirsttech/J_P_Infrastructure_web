<?php

namespace Modules\IncomeMaster\Database\Seeders;

use Illuminate\Database\Seeder;

class IncomeMasterDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
