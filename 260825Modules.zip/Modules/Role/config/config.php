<?php

return [
    'name' => 'Role',
];
