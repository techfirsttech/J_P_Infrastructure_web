<?php

return [
    'siteMaster' => 'Site Master',
    'list' => 'Site Master List',
    'add' => 'Add Site Master',
    'edit' => 'Edit Site Master',
    'state' => 'State',
    'city' => 'City',
    'country' => 'Country',
    'site_name' => 'Site Master Name',
    'user' => 'User',
    'pincode' => 'Pincode',
    'address' => 'Address',
    'enter_site_name' => 'Enter Site name',
    'enter_unique_name' => 'The city name has already been taken',
    'select_country' => 'Select country',
    'select_state' => 'Select state',
];