<?php

namespace Modules\State\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\State\Models\State;
use Modules\Country\Models;
use Modules\Country\Models\Country;

class StateDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
