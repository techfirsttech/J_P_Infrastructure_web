<x-login::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('login.name') !!}</p>
</x-login::layouts.master>
