<?php

return [
    'name' => 'Supplier',
];
