<?php

return [
    'name' => 'Labour',
];
