@extends('layouts.app')

@section('content')
<div class="row g-6">
    <!-- <h1>Hello</h1> -->
</div>
@endsection
