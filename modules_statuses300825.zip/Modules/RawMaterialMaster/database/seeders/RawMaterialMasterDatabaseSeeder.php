<?php

namespace Modules\RawMaterialMaster\Database\Seeders;

use Illuminate\Database\Seeder;

class RawMaterialMasterDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
