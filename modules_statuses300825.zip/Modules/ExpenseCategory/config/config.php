<?php

return [
    'name' => 'ExpenseCategory',
];
