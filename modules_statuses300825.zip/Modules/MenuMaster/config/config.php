<?php

return [
    'name' => 'MenuMaster',
];
