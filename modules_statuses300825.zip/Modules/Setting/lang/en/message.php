<?php

return [
    'setting' => 'Setting',
    'company_name' => 'Company Name',
    'tag_line' => 'Tag Line',
    'gst_number' => 'GST Number',
    'pancard_number' => 'Pancard Number',
    'tan_number' => 'Tan Number',
    'email' => 'Email',
    'mobile' => 'Mobile',
    'address' => 'Company Address',
    'logo' => 'Logo',
    'logo_dark' => 'Logo For Dark Mode',
    'favicon' => 'Favicon',
];
