<?php

return [
    'state' => 'State',
    'list' => 'State List',
    'edit' => 'Edit State',
    'add' => 'Add State',
    'country' => 'Country',
    'name' => 'State Name',
    'code' => 'State Code',
    'enter_name' => 'Enter state name',
    'enter_unique_name' => 'The state name has already been taken',
];
