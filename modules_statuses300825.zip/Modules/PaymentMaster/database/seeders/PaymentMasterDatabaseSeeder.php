<?php

namespace Modules\PaymentMaster\Database\Seeders;

use Illuminate\Database\Seeder;

class PaymentMasterDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
