<?php

namespace Modules\RawMaterialCategory\Database\Seeders;

use Illuminate\Database\Seeder;

class RawMaterialCategoryDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
