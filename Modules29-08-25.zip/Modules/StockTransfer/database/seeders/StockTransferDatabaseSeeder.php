<?php

namespace Modules\StockTransfer\Database\Seeders;

use Illuminate\Database\Seeder;

class StockTransferDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
