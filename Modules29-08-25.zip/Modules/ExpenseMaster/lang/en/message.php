<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'expenseCategory' => 'Expense Category',
    'expense_category' => 'Expense Category',
    'name' => 'Expense Category Name',

    'add' => 'Add Expense Master',
    'edit' => 'Edit Expense Master',
    'site' => 'Site',
    'supervisor' => 'Supervisor',
    'amount' => 'Amount',
    'remark' => 'Remark',
    'list' => 'Expense Master List',
    'enter_amount' => 'Enter Amount',
    'select_site' => 'Select Site',
    'select_supervisor' => 'Select Supervisor',
    'expenseMaster' => 'Expense Master',
    'expenseCategoryName' => 'Expense Category',
    'ledger' => 'Ledger',
    'credit' => 'Credit',
    'debit' => 'Debit',
    'document' => 'Document',




];
