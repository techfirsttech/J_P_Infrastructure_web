<?php

return [
    'name' => 'RawMaterialMaster',
];
