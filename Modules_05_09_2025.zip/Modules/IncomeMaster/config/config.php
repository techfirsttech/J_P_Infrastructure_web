<?php

return [
    'name' => 'IncomeMaster',
];
