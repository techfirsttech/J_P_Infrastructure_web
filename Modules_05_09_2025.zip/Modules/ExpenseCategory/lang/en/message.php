<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'expenseCategory' => 'Expense Category',
    'expense_category' => 'Expense Category',
    'name' => 'Expense Category Name',

    'add' => 'Add Expense Category',
    'edit' => 'Edit Expense Category',
    'expense_category_name' => 'Expense Category Name',
    'list' => 'Expense Category List',
    'enter_expense_category_name' => 'Enter Expense Category Name',
    'choose_expense_category_status' => 'Choose Status',
    'enter_unique_expense_category_name' => 'Enter unique expense category name',




];
