<?php

return [
    'name' => 'Party',
];
