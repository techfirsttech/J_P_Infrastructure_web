<?php

return [
    'name' => 'ExpenseMaster',
];
