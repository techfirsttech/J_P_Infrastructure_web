<?php

return [
    'name' => 'City',
];
