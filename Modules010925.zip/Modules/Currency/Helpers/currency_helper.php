<?php


function currency_delete_check($id)
{
    return true;
}
