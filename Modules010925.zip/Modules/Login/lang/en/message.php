<?php

return [
    'action' => 'Action',
];
