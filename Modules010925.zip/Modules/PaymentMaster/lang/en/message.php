<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common

    'paymenttransfer' => 'Payment Transfer',


    'list' => 'Payment Transfer',
    'paymenttransfer' => 'Payment Transfer',
    'add' => 'Payment Transfer',
    'edit' => 'Edit Payment Transfer',
    'site' => 'Site',
    'supervisor' => 'Supervisor',
    'amount' => 'Amount',
    'remark' => 'Remark',
    'enter_amount' => 'Enter Amount',
    'select_site' => 'Select Site',
    'select_supervisor' => 'Select Supervisor',
    'expenseMaster' => 'Expense Master',
    'expenseCategoryName' => 'Expense Category',
    'ledger' => 'Ledger',
    'credit' => 'Credit',
    'debit' => 'Debit',
    'document' => 'Document',




];
