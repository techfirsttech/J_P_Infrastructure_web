<?php

return [
    'name' => 'StockTransfer',
];
