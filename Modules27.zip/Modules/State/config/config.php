<?php

return [
    'name' => 'State',
];
