<?php

namespace Modules\Contractor\Database\Seeders;

use Illuminate\Database\Seeder;

class ContractorDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
