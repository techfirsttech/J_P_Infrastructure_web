<?php

return [
    'country' => 'Country',
    'list' => 'Country List',
    'add' => 'Add Country',
    'edit' => 'Edit Country',
    'code' => 'Country Code',
    'name' => 'Country Name ',
    'enter_name' => 'Enter country name',
    'enter_unique_name' => 'The country name has already been taken',
];
