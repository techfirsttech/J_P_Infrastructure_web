<?php

return [
    'Role' => 'Role',
    'roles' => 'Role',
    'list' => 'Role List',
    'add' => 'Add Role',
    'edit' => 'Edit Role',
    'name' => 'Role Name',
    'role_permissions' => 'Role Permissions',
    'select_all' => 'Select All',
    'administrator_access' => 'Administrator Access',
    'allow_full_access' => 'Allows a full access to the system',
    'if_not' => 'if it doesn`t exist.',

    'enter_name' => 'The role name is required.',
    'enter_last_name' => 'Enter last name',
    'enter_mobile' => 'Enter mobile',
];