<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'contractor' => 'Contractor',
    'expense_category' => 'Expense Category',
    'name' => 'Expense Category Name',

    'select_site' => 'Select Site',
    'site' => 'Site',
    'add' => 'Add Contractor',
    'edit' => 'Edit Contractor',
    'contractor_name' => 'Contractor Name',
    'mobile' => 'Mobile',
    'list' => 'Contractor List',
    'enter_contractor_name' => 'Enter Contractor Name',
    'enter_unique_contractor_name' => 'Enter unique Contractor name',




];
