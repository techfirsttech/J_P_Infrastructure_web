<?php

return [
    'dashboard' => 'Dashboard',
    'action' => 'Action',
    'addNew' => 'Add New',
    'submit' => 'Submit',
    'cancel' => 'Cancel',
    'menu-das' => 'Dashboard',

    'filter' => 'Filter',
    'date_filter' => 'Date Filter',
    'today' => 'Today',
    'week' => 'Week',
    'month' => 'Month',
    'year' => 'Year',
    'custom' => 'Custom',
];
