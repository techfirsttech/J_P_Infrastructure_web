<?php

return [
    'name' => 'RawMaterialCategory',
];
