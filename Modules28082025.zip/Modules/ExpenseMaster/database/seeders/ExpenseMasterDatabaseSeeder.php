<?php

namespace Modules\ExpenseMaster\Database\Seeders;

use Illuminate\Database\Seeder;

class ExpenseMasterDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
