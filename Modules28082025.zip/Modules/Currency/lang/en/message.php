<?php

return [
    'currency_master' => 'Currency Master',
    'list' => 'Currency List',
    'name' => 'Name',
    'symbol' => 'Symbol',
    'add' => 'Add Currency',
    'edit' => 'Edit Currency',
    'enter_symbol' => 'Enter symbol',
    'enter_name' => 'Enter currency name',
    'enter_unique_name' => 'The currency name has already been taken',
];
