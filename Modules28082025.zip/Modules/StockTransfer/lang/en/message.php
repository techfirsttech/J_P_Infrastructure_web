<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'materialMaster' => 'Raw Material Master',
    'rawMaterialMaster' => 'Raw Material Master',
    'material_master' => 'Raw Material Master',
    'raw_material_master' => 'Raw Material Master',
    'name' => 'Raw Material Name',

    'add' => 'Add Raw Material Master',
    'edit' => 'Edit Raw Material Master',
    'material_category_name' => 'Raw Material Name',
    'list' => 'Stock Transfer',
    'enter_material_category_name' => 'Enter Raw Material Name',
    'enter_material_category_name' => 'Enter Raw Material Name',
    'enter_unique_material_category_name' => 'Enter unique raw material name',
    'material_category' => 'Raw Material Category',
    'materialName' => 'Raw Material Name',
    'material_name' => 'Raw Material Name',
    'material_code' => 'Raw Material Code',
    'unit' => 'Unit',
    'alert_quantity' => 'Alert Quantity',
    'tax' => 'Tax',
    'enter_material_name' => 'Enter Material Name',
    'transaction' => 'In/Out Transaction',


    'stocktransfer' => 'Stock Transfer',




];
