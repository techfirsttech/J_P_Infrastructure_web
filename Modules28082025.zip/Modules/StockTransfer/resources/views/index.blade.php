@extends('layouts.app')
@section('title', __('stocktransfer::message.list'))
@section('content')
    <style>
        .select2-search__field {
            width: auto !important;
            display: inline-block !important;
        }
    </style>

    <div class="row mb-3">
        <div class="col-md-3 form-group custom-input-group">
            <label for="from_site_id" class="form-label">Material</label>
            <select id="from_site_id" class="select2 form-select">
                <option value="">All Sites</option>
                @foreach ($sites as $site)
                    <option value="{{ $site->id }}">{{ $site->site_name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3 form-group custom-input-group">
            <label for="to_site_id" class="form-label">Material</label>
            <select id="to_site_id" class="select2 form-select">
                <option value="">All Sites</option>
                @foreach ($sites as $site)
                    <option value="{{ $site->id }}">{{ $site->site_name }}</option>
                @endforeach
            </select>
        </div>

        {{-- <div class="col-md-3 form-group custom-input-group mt-2">
            <label for="filter_start_date" class="form-label">Start Date</label>
            <input type="text" class="form-control flatpickr-date" id="filter_start_date" placeholder="Start Date">
        </div>

        <div class="col-md-3 form-group custom-input-group mt-2">
            <label for="filter_end_date" class="form-label">End Date</label>
            <input type="text" class="form-control flatpickr-date" id="filter_end_date" placeholder="End Date">
        </div> --}}

        <div class="col-md-3 text-start pt-4 mt-2">
            <button class="btn btn-primary" id="filter_button"><i class="fa fa-search"></i></button>
            <button class="btn btn-secondary" id="reset_button"><i class="fa fa-refresh"></i></button>
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-2">
            <h5 class="content-header-title float-start mb-0"> Stock Transfer</h5>
            {{-- @can('site-master-create')
                <a href="{{ route('stocktransfer.create') }}" class="btn btn-sm btn-primary float-end new-create"><i
                        class="fa fa-plus me-50"></i> {{ __('message.common.addNew') }}</a>
            @endcan --}}
        </div>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table id="table" class="datatables-basic table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>From Site</th>
                                <th>To Site</th>
                                <th>Material</th>
                                <th>Quantity</th>
                                {{-- <th>{{ __('stocktransfer::message.quantity') }}</th>
                                <th>{{ __('stocktransfer::message.tax') }}</th>
                                <th>{{ __('message.common.action') }}</th> --}}
                            </tr>
                        </thead>
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('pagescript')
    <script type="application/javascript">
    @if($message = Session::get('error'))
    toastr.error("{{ addslashes($message) }}", "Error");
    @endif

        'use strict';
    const URL = "{{route('stocktransfer.index')}}";

    var table = '';
    var assignId = '';
    $(function() {
        table = $('#table').DataTable({
           ajax: {
                url: URL,
                data: function(d) {
                    d.from_site_id = $('#from_site_id').val();
                    d.to_site_id = $('#to_site_id').val();
                    d.start_date = $('#start_date').val();
                    d.end_date = $('#end_date').val();
                }
            },
            processing: true,
            serverSide: true,
            fixedHeader: false,
            scrollX: true,
            bScrollInfinite: true,
            bScrollCollapse: true,
            sScrollY: "465px",
            aLengthMenu: [
                [15, 30, 50, 100, -1],
                [15, 30, 50, 100, "All"]
            ],
            order: [
                [0, 'asc']
            ],
            columns: [{
                    data: 'id',
                    render: function(data, type, row, meta) {
                        var rowNumber = meta.row + meta.settings._iDisplayStart + 1;
                        var isResponsive = meta.settings.responsive && meta.settings.responsive.details;
                        if (type === 'display' && isResponsive && meta.settings.responsive.details.type === 'column') {
                            return '';
                        } else {
                            return rowNumber;
                        }
                    },
                    orderable: false,
                    createdCell: function(td, cellData, rowData, row, col) {
                        var isResponsive = table.responsive.hasHidden();
                        if (isResponsive) {
                            $(td).addClass('dtr-control');
                        } else {
                            $(td).removeClass('dtr-control');
                        }
                    }
                },
                {
                    data: 'from_site_name',
                    name: 'from_site_name'
                },
                {
                    data: 'to_site_name',
                    name: 'to_site_name'
                },
                {
                    data: 'material_name',
                    name: 'material_name'
                },
                {
                    data: 'quantity',
                    name: 'quantity'
                }
                // {
                //     data: 'alert_quantity',
                //     name: 'alert_quantity'
                // },
                // {
                //     data: 'tax',
                //     name: 'tax'
                // },
                // {
                //     data: 'action',
                //     name: 'action',
                //     orderable: false,
                //     sortable: false
                // },
            ],
            initComplete: function(settings, json) {
                var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
                var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
                    return new bootstrap.Tooltip(tooltipTriggerEl)
                })
            },

        });
    });

      // Filter Button
    $('#filter_button').click(function () {
        table.ajax.reload();
    });

    // Reset Button
    $('#reset_button').click(function () {
        $('#from_site_id').val('').trigger('change');
        $('#to_site_id').val('').trigger('change');
        // $('#filter_supervisor_id').val('').trigger('change');
        // $('#filter_type').val('').trigger('change');
        // $('#filter_start_date').val('');
        // $('#filter_end_date').val('');
        table.ajax.reload();
    });



</script>
    <script src="{{ asset('assets/custom/delete.js') }}"></script>
    <script src="{{ asset('assets/custom/status.js') }}"></script>
@endsection
