<?php

return [
    'name' => 'PaymentMaster',
];
