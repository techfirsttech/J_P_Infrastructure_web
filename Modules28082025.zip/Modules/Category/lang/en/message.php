<?php

return [
    'category' => 'Category',
    'list' => 'Category List',
    'add' => 'Add Category',
    'edit' => 'Edit Category',
    'name' => 'Category Name',
    'parent' => 'Parent',
    'is_parent' => 'Is Parent',
    'select_parent' => 'Select parent',
    'select_parent_category' => 'Select parent category',
    'enter_name' => 'Enter category name',
    'enter_unique_name' => 'The category name has already been taken',
];
