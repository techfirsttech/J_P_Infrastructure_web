<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'attendance' => 'Attendance',

    'add' => 'Add Attendance',
    'edit' => 'Edit Attendance',
    'site' => 'Site',
    'site_name' => 'Site',
    'supervisor' => 'Supervisor',
    'amount' => 'Amount',
    'remark' => 'Remark',
    'list' => 'Attendance List',
    'enter_amount' => 'Enter Amount',
    'select_site' => 'Select Site',
    'select_supervisor' => 'Select Supervisor',
    'contractor' => 'Contractor',
    'labour' => 'Labour',
    'type' => 'Type',
    'date' => 'Date',




];
