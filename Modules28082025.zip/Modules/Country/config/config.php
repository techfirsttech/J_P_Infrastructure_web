<?php

return [
    'name' => 'Country',
];
