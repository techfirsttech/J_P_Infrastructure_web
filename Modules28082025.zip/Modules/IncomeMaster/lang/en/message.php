<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'income' => 'Income Master',
    'incomeMaster' => 'Income Master',
    'name' => 'Income Name',

    'add' => 'Add Income Master',
    'edit' => 'Edit Income Master',
    'site' => 'Site',
    'supervisor' => 'Supervisor',
    'amount' => 'Amount',
    'remark' => 'Remark',
    'list' => 'Income Master List',
    'enter_amount' => 'Enter Amount',
    'select_site' => 'Select Site',
    'select_supervisor' => 'Select Supervisor',




];
