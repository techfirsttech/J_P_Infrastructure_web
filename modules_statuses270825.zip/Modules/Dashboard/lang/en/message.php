<?php

return [

    'dashboard' => 'Dashboard',
    'action' => 'Action',
    'addNew' => 'Add New',
    'submit' => 'Submit',
    'cancel' => 'Cancel',
    'menu-das' => 'Dashboard',
];