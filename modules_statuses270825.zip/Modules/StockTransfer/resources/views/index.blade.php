<x-stocktransfer::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('stocktransfer.name') !!}</p>
</x-stocktransfer::layouts.master>
