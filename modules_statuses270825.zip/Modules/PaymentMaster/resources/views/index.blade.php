<x-paymentmaster::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('paymentmaster.name') !!}</p>
</x-paymentmaster::layouts.master>
