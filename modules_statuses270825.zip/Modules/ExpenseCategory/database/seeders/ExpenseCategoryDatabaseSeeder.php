<?php

namespace Modules\ExpenseCategory\Database\Seeders;

use Illuminate\Database\Seeder;

class ExpenseCategoryDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
