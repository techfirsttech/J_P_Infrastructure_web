<?php

return [
    'unit' => 'Unit',
    'list' => 'Unit List',
    'add' => 'Add Unit',
    'edit' => 'Edit Unit',
    'name' => 'Unit Name',
    'unit_value' => 'Unit Value',
    'sub_unit' => 'Sub Unit',
    'sub_unit_value' => 'Sub Unit Value',
    'enter_name' => 'Enter unit name',
    'enter_unique_unit' => 'The unit name has already been taken',
];
