<?php

return [

    'English' => 'English',
    'Hindi' => 'Hindi',
    'Gujarati' => 'Gujarati',
    'Language' => 'Language',
    'dashboard' => 'Dashboard',
    'general_master' => 'General',
    'raw_material' => 'Raw Material',

    //common
    'materialCategory' => 'Raw Material Category',
    'rawMaterialCategory' => 'Raw Material Category',
    'material_category' => 'Raw Material Category',
    'raw_material_category' => 'Raw Material Category',
    'name' => 'Material Category Name',

    'add' => 'Add Raw Material Category',
    'edit' => 'Edit Raw Material Category',
    'material_category_name' => 'Material Category Name',
    'list' => 'Raw Material Category List',
    'enter_material_category_name' => 'Enter Material Category Name',
    'enter_material_category_name' => 'Enter Material Category Name',
    'enter_unique_material_category_name' => 'Enter unique material category name',




];
